//
//  Sub1CollectionViewCell.swift
//  Prac2CollecView
//
//  Created by Deepak B on 25/05/22.
//

import UIKit

class Sub1CollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var imgView: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
